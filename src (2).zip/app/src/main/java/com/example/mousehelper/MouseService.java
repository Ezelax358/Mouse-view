package com.example.mousehelper;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.AccessibilityServiceInfo;
import android.accessibilityservice.GestureDescription;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Path;
import android.graphics.Rect;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.view.InputDevice;
import android.view.MotionEvent;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;
import android.widget.Toast;

public class MouseService extends AccessibilityService {

    private static final long DUR = 30;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private SharedPreferences sp;
    private String fgPkg = "";
    private boolean running = false;
    private boolean busy = false;
    private long busySince = 0;
    private int announcedStep = 0;

    private boolean primaryDown = false, secondaryDown = false;
    private boolean pressedP = false, pressedS = false;
    private boolean hasLast = false;
    private float lastX, lastY;
    private float accX = 0f, accY = 0f;

    private GestureDescription.StrokeDescription camStroke = null;
    private GestureDescription.StrokeDescription fireStroke = null;
    private float camCurX, camCurY, fireCurX, fireCurY;
    private int camIdle = 0;

    private final Runnable tick = new Runnable() {
        @Override
        public void run() {
            safeTick();
            handler.postDelayed(this, 15);
        }
    };

    private void safeTick() {
        try {
            doTick();
        } catch (Throwable ignored) {
            busy = false;
            camStroke = null;
            fireStroke = null;
        }
    }

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        sp = getSharedPreferences("cfg", MODE_PRIVATE);
        AccessibilityServiceInfo info = getServiceInfo();
        if (info != null) {
            info.setMotionEventSources(InputDevice.SOURCE_MOUSE);
            setServiceInfo(info);
        }
        if (!running) {
            running = true;
            handler.postDelayed(tick, 15);
        }
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        if (event.getEventType() == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED
                && event.getPackageName() != null) {
            fgPkg = event.getPackageName().toString().toLowerCase();
        }
    }

    @Override
    public void onInterrupt() {
    }

    private Rect screen() {
        WindowManager wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        return wm.getCurrentWindowMetrics().getBounds();
    }

    @Override
    public void onMotionEvent(MotionEvent e) {
        if (sp == null) return;
        if (!isActive()) {
            hasLast = false;
            primaryDown = false;
            secondaryDown = false;
            return;
        }
        int a = e.getActionMasked();
        if (a == MotionEvent.ACTION_HOVER_EXIT || a == MotionEvent.ACTION_CANCEL) {
            hasLast = false;
            primaryDown = false;
            secondaryDown = false;
            return;
        }
        float x = e.getX();
        float y = e.getY();
        int bs = e.getButtonState();
        boolean pd = (bs & MotionEvent.BUTTON_PRIMARY) != 0;
        boolean sd = (bs & MotionEvent.BUTTON_SECONDARY) != 0;
        boolean pressEdge = (pd && !primaryDown) || (sd && !secondaryDown);

        int cs = sp.getInt("calib", 0);
        if (cs > 0) {
            if (pressEdge) {
                Rect r = screen();
                float fx = x / r.width();
                float fy = y / r.height();
                SharedPreferences.Editor ed = sp.edit();
                if (cs == 1) {
                    ed.putFloat("scopeXf", fx).putFloat("scopeYf", fy);
                } else if (cs == 2) {
                    ed.putFloat("fireXf", fx).putFloat("fireYf", fy);
                } else {
                    ed.putFloat("camXf", fx).putFloat("camYf", fy);
                }
                ed.putInt("calib", cs >= 3 ? 0 : cs + 1).apply();
            }
            primaryDown = pd;
            secondaryDown = sd;
            lastX = x;
            lastY = y;
            hasLast = true;
            return;
        }

        if (hasLast) {
            accX += x - lastX;
            accY += y - lastY;
        }
        lastX = x;
        lastY = y;
        hasLast = true;

        if (pd && !primaryDown) pressedP = true;
        if (sd && !secondaryDown) pressedS = true;
        primaryDown = pd;
        secondaryDown = sd;
    }

    private boolean isActive() {
        if (sp == null) return false;
        if (!sp.getBoolean("enabled", true)) return false;
        String f = sp.getString("pkg", "dudetheft").trim().toLowerCase();
        return f.isEmpty() || fgPkg.contains(f);
    }

    private static float clamp(float v, float lo, float hi) {
        return Math.max(lo, Math.min(hi, v));
    }

    private void announce(int step) {
        String t;
        if (step == 1) t = "1/3: Fare imlecini DÜRBÜN düğmesinin üstüne getirip tıkla";
        else if (step == 2) t = "2/3: Fare imlecini ATEŞ düğmesinin üstüne getirip tıkla";
        else if (step == 3) t = "3/3: KAMERA için ekranda boş bir yere tıkla";
        else t = "Kalibrasyon bitti";
        Toast.makeText(this, t, Toast.LENGTH_LONG).show();
    }

    private void doTick() {
        if (sp == null) return;

        int cs = sp.getInt("calib", 0);
        if (cs != announcedStep) {
            announce(cs);
            announcedStep = cs;
        }

        if (busy) {
            if (SystemClock.uptimeMillis() - busySince > 500) {
                busy = false;
                camStroke = null;
                fireStroke = null;
            }
            return;
        }

        Rect r = screen();
        float w = r.width();
        float h = r.height();

        boolean active = isActive() && cs == 0;
        boolean swap = sp.getBoolean("swap", false);
        boolean fireHeld = swap ? secondaryDown : primaryDown;
        boolean firePress = swap ? pressedS : pressedP;
        boolean scopePress = swap ? pressedP : pressedS;
        pressedP = false;
        pressedS = false;
        if (!active) {
            fireHeld = false;
            firePress = false;
            scopePress = false;
            accX = 0f;
            accY = 0f;
        }

        float sens = Math.max(1, sp.getInt("sens", 4)) / 4f;
        float ddx = accX * sens * (sp.getBoolean("invX", false) ? -1f : 1f);
        float ddy = accY * sens * (sp.getBoolean("invY", false) ? -1f : 1f);
        boolean moving = Math.abs(ddx) >= 0.5f || Math.abs(ddy) >= 0.5f;
        if (moving) {
            accX = 0f;
            accY = 0f;
        }

        GestureDescription.Builder gb = new GestureDescription.Builder();
        boolean any = false;

        // ---- Kamera: kesintisiz tek bir parmak sürüklemesi ----
        float cx = w * sp.getFloat("camXf", 0.70f);
        float cy = h * sp.getFloat("camYf", 0.50f);
        float rad = Math.min(w, h) * 0.25f;

        if (camStroke == null) {
            if (active && moving) {
                float ex = clamp(cx + ddx, cx - rad, cx + rad);
                float ey = clamp(cy + ddy, cy - rad, cy + rad);
                Path p = new Path();
                p.moveTo(cx, cy);
                p.lineTo(ex, ey);
                camStroke = new GestureDescription.StrokeDescription(p, 0, DUR, true);
                camCurX = ex;
                camCurY = ey;
                camIdle = 0;
                gb.addStroke(camStroke);
                any = true;
            }
        } else {
            float ux = camCurX, uy = camCurY;
            boolean willContinue = true;
            if (moving) {
                ux = camCurX + ddx;
                uy = camCurY + ddy;
                camIdle = 0;
            } else {
                camIdle++;
                if (camIdle > 4) willContinue = false;
            }
            float nx = clamp(ux, cx - rad - 1f, cx + rad + 1f);
            float ny = clamp(uy, cy - rad - 1f, cy + rad + 1f);
            nx = clamp(nx, 1f, w - 2f);
            ny = clamp(ny, 1f, h - 2f);
            if (nx != ux || ny != uy) willContinue = false;
            if (!active) willContinue = false;
            Path p = new Path();
            p.moveTo(camCurX, camCurY);
            if (nx != camCurX || ny != camCurY) p.lineTo(nx, ny);
            camStroke = camStroke.continueStroke(p, 0, DUR, willContinue);
            gb.addStroke(camStroke);
            any = true;
            camCurX = nx;
            camCurY = ny;
            if (!willContinue) camStroke = null;
        }

        // ---- Ateş: basılı tutunca parmak basılı kalır, tek tıkta kısa dokunuş ----
        if (fireStroke == null) {
            if (active && (fireHeld || firePress)) {
                fireCurX = w * sp.getFloat("fireXf", 0.88f);
                fireCurY = h * sp.getFloat("fireYf", 0.70f);
                Path p = new Path();
                p.moveTo(fireCurX, fireCurY);
                boolean cont = fireHeld;
                GestureDescription.StrokeDescription s =
                        new GestureDescription.StrokeDescription(p, 0, DUR, cont);
                gb.addStroke(s);
                any = true;
                if (cont) fireStroke = s;
            }
        } else {
            boolean cont = fireHeld && active;
            Path p = new Path();
            p.moveTo(fireCurX, fireCurY);
            fireStroke = fireStroke.continueStroke(p, 0, DUR, cont);
            gb.addStroke(fireStroke);
            any = true;
            if (!cont) fireStroke = null;
        }

        // ---- Dürbün: tek dokunuş ----
        if (active && scopePress) {
            Path p = new Path();
            p.moveTo(w * sp.getFloat("scopeXf", 0.92f), h * sp.getFloat("scopeYf", 0.40f));
            gb.addStroke(new GestureDescription.StrokeDescription(p, 0, DUR));
            any = true;
        }

        if (any) {
            busy = true;
            busySince = SystemClock.uptimeMillis();
            boolean ok = dispatchGesture(gb.build(), new GestureResultCallback() {
                @Override
                public void onCompleted(GestureDescription g) {
                    busy = false;
                    safeTick();
                }

                @Override
                public void onCancelled(GestureDescription g) {
                    busy = false;
                    camStroke = null;
                    fireStroke = null;
                }
            }, handler);
            if (!ok) {
                busy = false;
                camStroke = null;
                fireStroke = null;
            }
        }
    }

    @Override
    public boolean onUnbind(Intent intent) {
        handler.removeCallbacks(tick);
        running = false;
        return super.onUnbind(intent);
    }
}
