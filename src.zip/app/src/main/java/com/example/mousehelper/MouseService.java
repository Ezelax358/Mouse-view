package com.example.mousehelper;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.AccessibilityServiceInfo;
import android.accessibilityservice.GestureDescription;
import android.content.SharedPreferences;
import android.graphics.Path;
import android.graphics.Rect;
import android.os.Handler;
import android.os.Looper;
import android.view.InputDevice;
import android.view.MotionEvent;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;

public class MouseService extends AccessibilityService {

    private final Handler handler = new Handler(Looper.getMainLooper());
    private SharedPreferences sp;
    private String fgPkg = "";
    private boolean running = false;

    private boolean leftDown = false;
    private boolean rightHeld = false;
    private boolean rightPending = false;
    private boolean hasLast = false;
    private float lastX, lastY;
    private float accX = 0f, accY = 0f;

    private final Runnable tick = new Runnable() {
        @Override
        public void run() {
            try {
                doTick();
            } catch (Throwable ignored) {
            }
            handler.postDelayed(this, 50);
        }
    };

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        sp = getSharedPreferences("cfg", MODE_PRIVATE);
        AccessibilityServiceInfo info = getServiceInfo();
        if (info != null) {
            info.setMotionEventSources(InputDevice.SOURCE_MOUSE);
            setServiceInfo(info);
        }
        if (!running) {
            running = true;
            handler.postDelayed(tick, 50);
        }
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        if (event.getEventType() == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED
                && event.getPackageName() != null) {
            fgPkg = event.getPackageName().toString().toLowerCase();
        }
    }

    @Override
    public void onInterrupt() {
    }

    @Override
    public void onMotionEvent(MotionEvent e) {
        if (!isActive()) {
            leftDown = false;
            hasLast = false;
            return;
        }
        int a = e.getActionMasked();
        if (a == MotionEvent.ACTION_HOVER_EXIT || a == MotionEvent.ACTION_CANCEL) {
            hasLast = false;
            leftDown = false;
            return;
        }
        float x = e.getX();
        float y = e.getY();
        if (hasLast) {
            accX += x - lastX;
            accY += y - lastY;
        }
        lastX = x;
        lastY = y;
        hasLast = true;

        int bs = e.getButtonState();
        leftDown = (bs & MotionEvent.BUTTON_PRIMARY) != 0;
        boolean right = (bs & MotionEvent.BUTTON_SECONDARY) != 0;
        if (right && !rightHeld) {
            rightPending = true;
        }
        rightHeld = right;
    }

    private boolean isActive() {
        if (sp == null) return false;
        if (!sp.getBoolean("enabled", true)) return false;
        String f = sp.getString("pkg", "dudetheft").trim().toLowerCase();
        return f.isEmpty() || fgPkg.contains(f);
    }

    private static float clamp(float v, float lo, float hi) {
        return Math.max(lo, Math.min(hi, v));
    }

    private void doTick() {
        if (!isActive()) {
            accX = 0f;
            accY = 0f;
            rightPending = false;
            return;
        }
        WindowManager wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        Rect r = wm.getCurrentWindowMetrics().getBounds();
        float w = r.width();
        float h = r.height();

        GestureDescription.Builder gb = new GestureDescription.Builder();
        boolean any = false;

        float sens = Math.max(1, sp.getInt("sens", 8)) / 4f;
        float ddx = accX * sens * (sp.getBoolean("invX", false) ? -1f : 1f);
        float ddy = accY * sens * (sp.getBoolean("invY", false) ? -1f : 1f);
        accX = 0f;
        accY = 0f;

        if (Math.abs(ddx) >= 1f || Math.abs(ddy) >= 1f) {
            float maxD = Math.min(w, h) * 0.3f;
            ddx = clamp(ddx, -maxD, maxD);
            ddy = clamp(ddy, -maxD, maxD);
            float cx = w * sp.getInt("camX", 70) / 100f;
            float cy = h * sp.getInt("camY", 50) / 100f;
            Path p = new Path();
            p.moveTo(cx, cy);
            p.lineTo(clamp(cx + ddx, 0, w - 1), clamp(cy + ddy, 0, h - 1));
            gb.addStroke(new GestureDescription.StrokeDescription(p, 0, 40));
            any = true;
        }

        if (leftDown) {
            Path p = new Path();
            p.moveTo(w * sp.getInt("fireX", 88) / 100f, h * sp.getInt("fireY", 70) / 100f);
            gb.addStroke(new GestureDescription.StrokeDescription(p, 0, 40));
            any = true;
        }

        if (rightPending) {
            rightPending = false;
            Path p = new Path();
            p.moveTo(w * sp.getInt("scopeX", 92) / 100f, h * sp.getInt("scopeY", 40) / 100f);
            gb.addStroke(new GestureDescription.StrokeDescription(p, 0, 40));
            any = true;
        }

        if (any) {
            dispatchGesture(gb.build(), null, null);
        }
    }

    @Override
    public boolean onUnbind(android.content.Intent intent) {
        handler.removeCallbacks(tick);
        running = false;
        return super.onUnbind(intent);
    }
}
