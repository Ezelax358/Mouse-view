package com.example.mousehelper;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.provider.Settings;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;

public class MainActivity extends Activity {

    private SharedPreferences sp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        sp = getSharedPreferences("cfg", MODE_PRIVATE);

        ScrollView sv = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        int pad = (int) (16 * getResources().getDisplayMetrics().density);
        root.setPadding(pad, pad, pad, pad);
        sv.addView(root);
        setContentView(sv);

        TextView info = new TextView(this);
        info.setText("1) Aşağıdaki düğmeyle Erişilebilirlik ayarlarını aç, \"Mouse Yardımcısı\"nı bul ve aç.\n"
                + "2) Oyunu aç. Mouse'u oynatınca kamera döner, sol tık ateş eder, sağ tık dürbün tuşuna dokunur.\n"
                + "3) Ateş ve dürbün yüzdelerini oyundaki buton konumlarına, kamera noktasını ekranda boş bir yere ayarla.\n"
                + "Not: Mouse imleci ekran kenarına dayanınca kamera durur; mouse'u geri çek.\n");
        root.addView(info);

        Button open = new Button(this);
        open.setText("Erişilebilirlik ayarlarını aç");
        open.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));
            }
        });
        root.addView(open);

        check(root, "Aktif", "enabled", true);
        check(root, "X yönünü ters çevir", "invX", false);
        check(root, "Y yönünü ters çevir", "invY", false);

        TextView pt = new TextView(this);
        pt.setText("Oyun paket adı filtresi (boş bırakırsan her uygulamada çalışır):");
        root.addView(pt);
        EditText et = new EditText(this);
        et.setSingleLine(true);
        et.setText(sp.getString("pkg", "dudetheft"));
        et.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int a, int b, int c) {
            }

            @Override
            public void onTextChanged(CharSequence s, int a, int b, int c) {
            }

            @Override
            public void afterTextChanged(Editable s) {
                sp.edit().putString("pkg", s.toString()).apply();
            }
        });
        root.addView(et);

        slider(root, "Hassasiyet", "sens", 8, 40);
        slider(root, "Kamera noktası X %", "camX", 70, 100);
        slider(root, "Kamera noktası Y %", "camY", 50, 100);
        slider(root, "Ateş butonu X %", "fireX", 88, 100);
        slider(root, "Ateş butonu Y %", "fireY", 70, 100);
        slider(root, "Dürbün butonu X %", "scopeX", 92, 100);
        slider(root, "Dürbün butonu Y %", "scopeY", 40, 100);
    }

    private void check(LinearLayout root, String label, final String key, boolean def) {
        CheckBox cb = new CheckBox(this);
        cb.setText(label);
        cb.setChecked(sp.getBoolean(key, def));
        cb.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton b, boolean checked) {
                sp.edit().putBoolean(key, checked).apply();
            }
        });
        root.addView(cb);
    }

    private void slider(LinearLayout root, final String label, final String key, int def, int max) {
        int cur = sp.getInt(key, def);
        final TextView tv = new TextView(this);
        tv.setText(label + ": " + cur);
        SeekBar sb = new SeekBar(this);
        sb.setMax(max);
        sb.setProgress(cur);
        sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar s, int p, boolean fromUser) {
                tv.setText(label + ": " + p);
                sp.edit().putInt(key, p).apply();
            }

            @Override
            public void onStartTrackingTouch(SeekBar s) {
            }

            @Override
            public void onStopTrackingTouch(SeekBar s) {
            }
        });
        root.addView(tv);
        root.addView(sb);
    }
}
