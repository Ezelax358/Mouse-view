package com.example.mousehelper;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.provider.Settings;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {

    private SharedPreferences sp;
    private TextView diagView;

    private void refreshDiag() {
        if (diagView != null) {
            diagView.setText("Durum: " + sp.getString("diag", "-"));
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        refreshDiag();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        sp = getSharedPreferences("cfg", MODE_PRIVATE);

        ScrollView sv = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        int pad = (int) (16 * getResources().getDisplayMetrics().density);
        root.setPadding(pad, pad, pad, pad);
        sv.addView(root);
        setContentView(sv);

        TextView info = new TextView(this);
        info.setText("1) Erişilebilirlik ayarlarını aç, \"Mouse Yardımcısı\"nı aç.\n"
                + "2) Aşağıdaki \"Konumları öğret\" düğmesine bas, oyuna geç ve ekrandaki yönergeleri izle "
                + "(imleci dürbün, ateş düğmelerinin üstüne getirip tıkla, sonra kamera için boş bir yere tıkla).\n"
                + "3) Mouse'u oynat: kamera döner. Basılı tut: ateş eder. Diğer tuş: dürbün.\n"
                + "Tuşlar ters çıkarsa \"Sol/sağ tuşları değiştir\" kutusunu işaretle.\n"
                + "Not: İmleç ekran kenarına dayanınca kamera durur; mouse'u geri çek.\n");
        root.addView(info);

        Button open = new Button(this);
        open.setText("Erişilebilirlik ayarlarını aç");
        open.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));
            }
        });
        root.addView(open);

        Button calib = new Button(this);
        calib.setText("Konumları öğret (kalibrasyon)");
        calib.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sp.edit().putInt("calib", 1).apply();
                Toast.makeText(MainActivity.this,
                        "Şimdi oyuna geç; yönergeler ekranda çıkacak", Toast.LENGTH_LONG).show();
            }
        });
        root.addView(calib);

        check(root, "Aktif", "enabled", true);
        check(root, "Dürbün: basılı tut, bırakınca kapansın", "scopeHold", true);
        check(root, "Klasik kamera (kesik ama garantili; kapatırsan kesintisiz)", "classic", true);
        check(root, "Sol/sağ tuşları değiştir", "swap", false);
        check(root, "X yönünü ters çevir", "invX", false);
        check(root, "Y yönünü ters çevir", "invY", false);

        TextView pt = new TextView(this);
        pt.setText("Oyun paket adı filtresi (boş bırakırsan her uygulamada çalışır):");
        root.addView(pt);
        EditText et = new EditText(this);
        et.setSingleLine(true);
        et.setText(sp.getString("pkg", "dudetheft"));
        et.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int a, int b, int c) {
            }

            @Override
            public void onTextChanged(CharSequence s, int a, int b, int c) {
            }

            @Override
            public void afterTextChanged(Editable s) {
                sp.edit().putString("pkg", s.toString()).apply();
            }
        });
        root.addView(et);

        slider(root, "Hassasiyet", "sens", 8, 40);

        Button refresh = new Button(this);
        refresh.setText("Durumu yenile");
        refresh.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                refreshDiag();
            }
        });
        root.addView(refresh);
        diagView = new TextView(this);
        root.addView(diagView);
        refreshDiag();
    }

    private void check(LinearLayout root, String label, final String key, boolean def) {
        CheckBox cb = new CheckBox(this);
        cb.setText(label);
        cb.setChecked(sp.getBoolean(key, def));
        cb.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton b, boolean checked) {
                sp.edit().putBoolean(key, checked).apply();
            }
        });
        root.addView(cb);
    }

    private void slider(LinearLayout root, final String label, final String key, int def, int max) {
        int cur = sp.getInt(key, def);
        final TextView tv = new TextView(this);
        tv.setText(label + ": " + cur);
        SeekBar sb = new SeekBar(this);
        sb.setMax(max);
        sb.setProgress(cur);
        sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar s, int p, boolean fromUser) {
                tv.setText(label + ": " + p);
                sp.edit().putInt(key, p).apply();
            }

            @Override
            public void onStartTrackingTouch(SeekBar s) {
            }

            @Override
            public void onStopTrackingTouch(SeekBar s) {
            }
        });
        root.addView(tv);
        root.addView(sb);
    }
}
